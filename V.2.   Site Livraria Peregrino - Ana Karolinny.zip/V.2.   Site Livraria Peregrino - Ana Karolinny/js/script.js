function validarFormulario(){
    const nome = document.getElementById("nome").value
    const email = document.getElementById("email").value
    const message = document.getElementById("message").value
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

    if(nome == "" || email == "" || message == ""){
        alert("Por favor, preencha todos os campos corretamente.")
    } else if (!emailPattern.test(email)) {
        alert("Por favor, insira um endereço de email válido.")
    } else {
        alert("Enviado!")
    }
}
